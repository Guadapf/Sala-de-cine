package ar.edu.unlam.pb2.saladecine;

public enum Filas {
	A, B, C, D, E, F, G, H, I, J, K, L, M, N, Ñ, O
}
